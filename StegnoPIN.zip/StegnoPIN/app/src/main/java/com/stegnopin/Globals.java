package com.stegnopin;

import com.stegnopin.models.Accounts;
import com.stegnopin.models.Users;

/**
 * Created by Chandramouliswaran on 2/14/2018.
 */
public class Globals {
    public static String serverIP;
    public static Users lastLoggedInUser;
    public static String lastKeypadType;
    public static String lastPin="";
    public static String lastOtpPin;
    public static Accounts lastUserAccount;

}
